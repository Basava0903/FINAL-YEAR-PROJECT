classdef app2_updated < matlab.apps.AppBase

    % Properties that correspond to app components
    
    properties (Access = private)
    TextureBasedFaceAntispoofingUIFigure
  
        Panel_4           matlab.ui.container.Panel
        Image3            matlab.ui.control.Image
        Panel             matlab.ui.container.Panel
        NEXTButton        matlab.ui.control.Button
        Image             matlab.ui.control.Image
        Panel_2           matlab.ui.container.Panel
        ERRORPanel        matlab.ui.container.Panel
        RETRYButton       matlab.ui.control.Button
        MULTIPLEFACESDETECTEDTRYAGAINLabel  matlab.ui.control.Label
        Panel_3           matlab.ui.container.Panel
        UIAxes            matlab.ui.control.UIAxes
        BACKButton        matlab.ui.control.Button
        NEWButton         matlab.ui.control.Button
        SPOOFATTACKLabel  matlab.ui.control.Label
        REALLabel         matlab.ui.control.Label
        RESULTLabel       matlab.ui.control.Label
        Lamp              matlab.ui.control.Lamp
        Lamp2             matlab.ui.control.Lamp
        CAPTUREButton     matlab.ui.control.Button
        Image2            matlab.ui.control.Image
    end

    
    properties (Access = public)
        cam;
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: CAPTUREButton
        function CAPTUREButtonPushed(app, event)
            %app.upadatePreview();
            app.CAPTUREButton.Visible='off';
            app.Panel_4.Visible='on';
            
            
            image=snapshot(app.cam);
            FDetect = vision.CascadeObjectDetector;
            BB = step(FDetect,image);
            imshow(image,'Parent',app.UIAxes);
            
            for i=1:size(BB,1)
                rectangle(app.UIAxes,'Position',BB(i,:),'LineWidth',3,'LineStyle',"-","EdgeColor",'#39FF14');
            end
           
            drawnow;
            close all;
            img=[];
            img=image;
            try 
                output=main(img);
            catch ME
                delete(app.cam);
            end
            delete(app.cam);
            app.Panel_4.Visible='off';
            try
                    if output==0
                        app.SPOOFATTACKLabel.Visible='on';
                        app.Lamp2.Visible='on';    
                    else
                        app.REALLabel.Visible='on';
                        app.Lamp.Visible='on';
                    end
            catch ME
                app.ERRORPanel.Visible='on';
            end
            
            app.NEWButton.Visible='on';
        end

        % Button pushed function: NEXTButton
        function NEXTButtonPushed(app, event)
            app.ERRORPanel.Visible='off';
            app.BACKButton.Visible='on';
            app.SPOOFATTACKLabel.Visible='off';
            app.REALLabel.Visible='off';
            app.CAPTUREButton.Visible='on';
            app.Panel.Visible='off';
            app.Lamp.Visible='off';
            app.Lamp2.Visible='off';
            app.NEWButton.Visible='off';
            app.cam=webcam();
             try
                while isvalid(app.TextureBasedFaceAntispoofingUIFigure)
                    frame=snapshot(app.cam);
                    imshow(frame,'Parent',app.UIAxes);
                    FDetect = vision.CascadeObjectDetector;
                    BB = step(FDetect,frame);
                    imshow(frame,'Parent',app.UIAxes);
                    
                    for i=1:size(BB,1)
                        rectangle(app.UIAxes,'Position',BB(i,:),'LineWidth',2,'LineStyle',"-","EdgeColor",'#39FF14');
                    end
                   
                    drawnow;
                    close all;
                end
             
             catch ME   
             end
        end

        % Close request function: 
        % TextureBasedFaceAntispoofingUIFigure
        function TextureBasedFaceAntispoofingUIFigureCloseRequest(app, event)
            delete(app);
        end

        % Button pushed function: NEWButton
        function NEWButtonPushed(app, event)
            NEXTButtonPushed(app, event);
        end

        % Button pushed function: BACKButton
        function BACKButtonPushed(app, event)
            close all;
            delete(app.cam);
            app.Panel.Visible='on';
            app.BACKButton.Visible='off';
        end

        % Button pushed function: RETRYButton
        function RETRYButtonPushed(app, event)
             NEXTButtonPushed(app, event);
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create TextureBasedFaceAntispoofingUIFigure and hide until all components are created
            app.TextureBasedFaceAntispoofingUIFigure = uifigure('Visible', 'off');
            app.TextureBasedFaceAntispoofingUIFigure.Color = [0 0 0];
            app.TextureBasedFaceAntispoofingUIFigure.Position = [100 100 1366 700];
            app.TextureBasedFaceAntispoofingUIFigure.Name = 'Texture Based Face Anti-spoofing';
            app.TextureBasedFaceAntispoofingUIFigure.CloseRequestFcn = createCallbackFcn(app, @TextureBasedFaceAntispoofingUIFigureCloseRequest, true);
            app.TextureBasedFaceAntispoofingUIFigure.WindowState = 'maximized';

            % Create Panel_2
            app.Panel_2 = uipanel(app.TextureBasedFaceAntispoofingUIFigure);
            app.Panel_2.BackgroundColor = [0 0 0];
            app.Panel_2.Position = [0 1 1365 699];

            % Create Image2
            app.Image2 = uiimage(app.Panel_2);
            app.Image2.Position = [-5 1 1366 700];
            app.Image2.ImageSource = 'Screenshot (95).png';

            % Create CAPTUREButton
            app.CAPTUREButton = uibutton(app.Panel_2, 'push');
            app.CAPTUREButton.ButtonPushedFcn = createCallbackFcn(app, @CAPTUREButtonPushed, true);
            app.CAPTUREButton.BackgroundColor = [0 0 1];
            app.CAPTUREButton.FontSize = 20;
            app.CAPTUREButton.FontColor = [1 1 1];
            app.CAPTUREButton.Position = [551 37 253 67];
            app.CAPTUREButton.Text = 'CAPTURE';

            % Create Lamp2
            app.Lamp2 = uilamp(app.Panel_2);
            app.Lamp2.Visible = 'off';
            app.Lamp2.Position = [924 167 186 186];
            app.Lamp2.Color = [1 0 0];

            % Create Lamp
            app.Lamp = uilamp(app.Panel_2);
            app.Lamp.Visible = 'off';
            app.Lamp.Position = [922 168 185 185];

            % Create RESULTLabel
            app.RESULTLabel = uilabel(app.Panel_2);
            app.RESULTLabel.FontSize = 44;
            app.RESULTLabel.FontWeight = 'bold';
            app.RESULTLabel.FontColor = [1 1 1];
            app.RESULTLabel.Position = [922 524 188 71];
            app.RESULTLabel.Text = 'RESULT:';

            % Create REALLabel
            app.REALLabel = uilabel(app.Panel_2);
            app.REALLabel.BackgroundColor = [1 1 1];
            app.REALLabel.HorizontalAlignment = 'center';
            app.REALLabel.FontSize = 44;
            app.REALLabel.FontColor = [0 1 0];
            app.REALLabel.Visible = 'off';
            app.REALLabel.Position = [922 403 162 64];
            app.REALLabel.Text = 'REAL';

            % Create SPOOFATTACKLabel
            app.SPOOFATTACKLabel = uilabel(app.Panel_2);
            app.SPOOFATTACKLabel.BackgroundColor = [1 1 1];
            app.SPOOFATTACKLabel.HorizontalAlignment = 'center';
            app.SPOOFATTACKLabel.FontSize = 44;
            app.SPOOFATTACKLabel.FontColor = [1 0 0];
            app.SPOOFATTACKLabel.Visible = 'off';
            app.SPOOFATTACKLabel.Position = [828 403 349 64];
            app.SPOOFATTACKLabel.Text = 'SPOOF/ATTACK';

            % Create NEWButton
            app.NEWButton = uibutton(app.Panel_2, 'push');
            app.NEWButton.ButtonPushedFcn = createCallbackFcn(app, @NEWButtonPushed, true);
            app.NEWButton.BackgroundColor = [0 0 1];
            app.NEWButton.FontSize = 20;
            app.NEWButton.FontColor = [1 1 1];
            app.NEWButton.Visible = 'off';
            app.NEWButton.Position = [627 36 186 68];
            app.NEWButton.Text = 'NEW';

            % Create BACKButton
            app.BACKButton = uibutton(app.Panel_2, 'push');
            app.BACKButton.ButtonPushedFcn = createCallbackFcn(app, @BACKButtonPushed, true);
            app.BACKButton.BackgroundColor = [1 1 1];
            app.BACKButton.FontSize = 20;
            app.BACKButton.Visible = 'off';
            app.BACKButton.Position = [1107 36 180 68];
            app.BACKButton.Text = 'BACK';

            % Create Panel_3
            app.Panel_3 = uipanel(app.Panel_2);
            app.Panel_3.BackgroundColor = [0 0 0];
            app.Panel_3.Position = [164 222 532 424];

            % Create UIAxes
            app.UIAxes = uiaxes(app.Panel_3);
            app.UIAxes.Toolbar.Visible = 'off';
            app.UIAxes.XTick = [];
            app.UIAxes.YTick = [];
            app.UIAxes.FontSize = 1;
            app.UIAxes.Box = 'on';
            app.UIAxes.Position = [19 18 524 389];

            % Create ERRORPanel
            app.ERRORPanel = uipanel(app.Panel_2);
            app.ERRORPanel.ForegroundColor = [1 0 0];
            app.ERRORPanel.Title = 'ERROR';
            app.ERRORPanel.Visible = 'off';
            app.ERRORPanel.FontWeight = 'bold';
            app.ERRORPanel.FontSize = 20;
            app.ERRORPanel.Position = [433 255 504 205];

            % Create MULTIPLEFACESDETECTEDTRYAGAINLabel
            app.MULTIPLEFACESDETECTEDTRYAGAINLabel = uilabel(app.ERRORPanel);
            app.MULTIPLEFACESDETECTEDTRYAGAINLabel.HorizontalAlignment = 'center';
            app.MULTIPLEFACESDETECTEDTRYAGAINLabel.FontSize = 20;
            app.MULTIPLEFACESDETECTEDTRYAGAINLabel.FontWeight = 'bold';
            app.MULTIPLEFACESDETECTEDTRYAGAINLabel.FontColor = [1 0 0];
            app.MULTIPLEFACESDETECTEDTRYAGAINLabel.Position = [1 81 503 70];
            app.MULTIPLEFACESDETECTEDTRYAGAINLabel.Text = 'MULTIPLE FACES DETECTED, TRY AGAIN !!';

            % Create RETRYButton
            app.RETRYButton = uibutton(app.ERRORPanel, 'push');
            app.RETRYButton.ButtonPushedFcn = createCallbackFcn(app, @RETRYButtonPushed, true);
            app.RETRYButton.FontSize = 25;
            app.RETRYButton.FontWeight = 'bold';
            app.RETRYButton.Position = [181 33 138 50];
            app.RETRYButton.Text = 'RETRY';

            % Create Panel
            app.Panel = uipanel(app.TextureBasedFaceAntispoofingUIFigure);
            app.Panel.BorderType = 'none';
            app.Panel.BackgroundColor = [0 0 0];
            app.Panel.Position = [3 -2 1366 700];

            % Create Image
            app.Image = uiimage(app.Panel);
            app.Image.Position = [47 -47 1273 798];
            app.Image.ImageSource = 'Screenshot (93).png';

            % Create NEXTButton
            app.NEXTButton = uibutton(app.Panel, 'push');
            app.NEXTButton.ButtonPushedFcn = createCallbackFcn(app, @NEXTButtonPushed, true);
            app.NEXTButton.BackgroundColor = [0 0 0];
            app.NEXTButton.FontSize = 44;
            app.NEXTButton.FontColor = [1 1 1];
            app.NEXTButton.Position = [553 25 244 68];
            app.NEXTButton.Text = 'NEXT';

            % Create Panel_4
            app.Panel_4 = uipanel(app.TextureBasedFaceAntispoofingUIFigure);
            app.Panel_4.Visible = 'off';
            app.Panel_4.BackgroundColor = [0 0 0];
            app.Panel_4.Position = [-5 -1 1365 701];

            % Create Image3
            app.Image3 = uiimage(app.Panel_4);
            app.Image3.Position = [282 139 803 422];
            app.Image3.ImageSource = '1707886263111.gif';

            % Show the figure after all components are created
            app.TextureBasedFaceAntispoofingUIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = app2_updated

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.TextureBasedFaceAntispoofingUIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.TextureBasedFaceAntispoofingUIFigure)
        end
    end
end