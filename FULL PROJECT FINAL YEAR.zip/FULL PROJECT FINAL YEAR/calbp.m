function [res]= calbp(mat)
%CA
    resImage=zeros(3,3,'uint8'); 
    resImage(:,1)=mat(:,1);
    resImage(:,3)=mat(:,4);
    for i=1:3
            resImage(i,2)=(mat(i,2)+mat(i,3))/2;
    end
    mat=resImage;
%LBP
    c=mat(2,2);
    for i=1:3
        for j=1:3
            if i==2 & j==2
                continue;
            elseif mat(i,j)>=c
                mat(i,j)=1;
            else
                mat(i,j)=0;
            end
        end
    end
   res=mat(3,3)*2^0+mat(3,2)*2^1+mat(3,1)*2^2+mat(2,1)*2^3+mat(1,1)*2^4+mat(1,2)*2^5+mat(1,3)*2^6+mat(2,3)*2^7;
end