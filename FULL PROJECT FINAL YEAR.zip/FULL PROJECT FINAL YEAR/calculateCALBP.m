function [resultImage]=calculateCALBP(img)
        
        
        [r,c]=size(img);
        resultImage=zeros(r,c,'uint8');
        for i=2:r-1
           for j=2:c-2
                temp=img(i-1:i+1,j-1:j+2);
                resultImage(i,j)=calbp(temp);
            end
        end
end