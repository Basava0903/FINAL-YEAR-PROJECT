%  global model;model=fitcsvm(featureValues,label);

function [output]= main(img)
        disp("MAIN");
        clc;
        clearvars -except model img;
        I=rgb2gray(img);
        FDetect = vision.CascadeObjectDetector;
        BB = step(FDetect,I);

        I2=imcrop(I,BB);
        I3=imresize(I2,[160 160]);


        imgSeg=mat2cell(I3,[40 40 40 40],[40 40 40 40]);
        tempFeatures=[];
        for k=1:4
            for m=1:4
                resultImage=calculateCALBP(imgSeg{m,k});
                features=histogram(resultImage,59);
                tempFeatures=[tempFeatures features.Values];
                close;
            end
        end
        featureValues=tempFeatures;
        global model;
        output=predict(model,featureValues);
        
        if output==0
               disp("Spoof image");
            else
                disp("Real image");
        end
end